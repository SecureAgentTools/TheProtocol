"""
TheProtocol SDK — Build and call A2A agents.

Usage:
    from theprotocol.models import Message, Task, AgentCard
    from theprotocol.agent import BaseA2AAgent, create_a2a_router
    from theprotocol.client import A2AClient, KeyManager
    from theprotocol.transfer import TransferClient   # smart send (auto-routed value movement)
"""

__version__ = "0.5.1"
