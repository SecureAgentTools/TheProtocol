"""
AGORA Exchange Client — trade org equity from agent code.

Market data is public; order/portfolio calls take the agent's JWT.

    ex = ExchangeClient("https://frame-c.theprotocol.cloud")
    book = await ex.book("BL1F")
    res = await ex.place_order(agent_jwt, "BL1F", "buy", qty=5, price="4.20")
    await ex.cancel_order(agent_jwt, res["order_id"])

Money model (why you can trust it): shares are registry-ledger entries; every
money leg settles through the venue escrow on TEG rails — buy escrow is taken
on placement, refunds/proceeds drain via the settlement worker. Fees come from
SELLER proceeds (a buy never pays more than its escrow). Supply Δ=0 by
construction; the venue self-checks via GET /exchange/admin/invariant.
"""
import logging
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


class ExchangeClient:
    """Client for an AGORA venue (one registry hosting an order book)."""

    def __init__(self, registry_url: str, timeout: float = 15.0):
        self.base = registry_url.rstrip("/") + "/api/v1/exchange"
        self._client: Optional[httpx.AsyncClient] = None
        self._timeout = timeout

    def _c(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                limits=httpx.Limits(max_connections=50, max_keepalive_connections=10),
            )
        return self._client

    async def aclose(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    @staticmethod
    def _auth(agent_jwt: str) -> Dict[str, str]:
        return {"Authorization": f"Bearer {agent_jwt}"}

    # ── market data (public) ──────────────────────────────────────────
    async def listings(self) -> List[Dict[str, Any]]:
        r = await self._c().get(f"{self.base}/listings")
        r.raise_for_status()
        return r.json().get("listings", [])

    async def listing(self, ref: str) -> Dict[str, Any]:
        r = await self._c().get(f"{self.base}/listings/{ref}")
        r.raise_for_status()
        return r.json()

    async def book(self, ref: str, depth: int = 12) -> Dict[str, Any]:
        r = await self._c().get(f"{self.base}/listings/{ref}/book", params={"depth": depth})
        r.raise_for_status()
        return r.json()

    async def trades(self, ref: str, limit: int = 50) -> List[Dict[str, Any]]:
        r = await self._c().get(f"{self.base}/listings/{ref}/trades", params={"limit": limit})
        r.raise_for_status()
        return r.json().get("trades", [])

    async def candles(self, ref: str, tf: str = "1h", limit: int = 120) -> List[Dict[str, Any]]:
        r = await self._c().get(f"{self.base}/listings/{ref}/candles", params={"tf": tf, "limit": limit})
        r.raise_for_status()
        return r.json().get("candles", [])

    async def federation_tickers(self) -> List[Dict[str, Any]]:
        """Every live venue this registry can see (server-side aggregate)."""
        r = await self._c().get(f"{self.base}/federation-tickers")
        r.raise_for_status()
        return r.json().get("venues", [])

    # ── trading (agent JWT) ───────────────────────────────────────────
    async def place_order(
        self, agent_jwt: str, listing: str, side: str, qty: int,
        price: Optional[str] = None, order_type: Optional[str] = None,
        client_order_id: Optional[str] = None, ttl_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Limit when `price` given (unless order_type overrides), else market.
        Returns {order_id, status, remaining, escrow_amount, fills[...]}."""
        body: Dict[str, Any] = {
            "listing": listing, "side": side, "qty": qty,
            "order_type": order_type or ("limit" if price is not None else "market"),
        }
        if price is not None:
            body["price"] = price
        if client_order_id:
            body["client_order_id"] = client_order_id
        if ttl_seconds:
            body["ttl_seconds"] = ttl_seconds
        r = await self._c().post(f"{self.base}/orders", json=body, headers=self._auth(agent_jwt))
        r.raise_for_status()
        return r.json()

    async def cancel_order(self, agent_jwt: str, order_id: str) -> Dict[str, Any]:
        r = await self._c().delete(f"{self.base}/orders/{order_id}", headers=self._auth(agent_jwt))
        r.raise_for_status()
        return r.json()

    async def my_orders(self, agent_jwt: str, listing: Optional[str] = None) -> List[Dict[str, Any]]:
        r = await self._c().get(f"{self.base}/orders/mine",
                                params={"listing": listing} if listing else {},
                                headers=self._auth(agent_jwt))
        r.raise_for_status()
        return r.json().get("orders", [])

    async def portfolio(self, agent_jwt: str) -> Dict[str, Any]:
        r = await self._c().get(f"{self.base}/portfolio", headers=self._auth(agent_jwt))
        r.raise_for_status()
        return r.json()

    async def ipo_buy(self, agent_jwt: str, ref: str, qty: int) -> Dict[str, Any]:
        r = await self._c().post(f"{self.base}/listings/{ref}/ipo/buy", json={"qty": qty},
                                 headers=self._auth(agent_jwt))
        r.raise_for_status()
        return r.json()
